const startSkill = require('./startSkill')
const spendingReport = require('./spendingReport')
const accessDatabase = require('./accessDatabase')

module.exports = {
    startSkill,
    spendingReport,
    accessDatabase
}
